package com.APITesting.SetTestData;

public class SetPostData {
	
	private String nodeid;
	private String userId;
	private String fulfillOrdNbr;
	private String upcNbr;
	private String activationType;
	private String code;
	private String oldCode;
	private String returnType;
	
	
	public String getnodeId() {
		return nodeid;
	}
	
	public void setnodeId(String nodeid) {
		this.nodeid=nodeid;
	}
	
	public String getuserId() {
		return userId;
	}
	
	public void setuserId(String userId) {
		this.userId=userId;
	}
	
	public String getfulfillOrdNbr() {
		return fulfillOrdNbr;
	}
	
	public void setfulfillOrdNbr(String fulfillOrdNbr) {
		this.fulfillOrdNbr=fulfillOrdNbr;
	}
	
	public String getupcNbr() {
		return upcNbr;
	}
	
	public void setupcNbr(String upcNbr) {
		this.upcNbr=upcNbr;
	}
	
	public String getactivationType() {
		return activationType;
	}
	
	public void setactivationType(String activationType) {
		this.activationType=activationType;
	}
	
	public String getcode() {
		return code;
	}
	
	public void setcode(String code) {
		this.code=code;
	}
	
	public String getoldcode() {
		return oldCode;
	}
	
	public void setoldCode(String oldCode) {
		this.oldCode=oldCode;
	}
	
	public String getreturnType() {
		return returnType;
	}
	
	public void setreturnType(String returnType) {
		this.returnType=returnType;
	}

}
