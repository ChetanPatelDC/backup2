export enum FONTS {
  Black = 'Poppins-Black',
  Bold = 'Poppins-Bold',
  Light = 'Poppins-Light',
  Medium = 'Poppins-Medium',
  Regular = 'Poppins-Regular',
  SemiBold = 'Poppins-SemiBold',
};

