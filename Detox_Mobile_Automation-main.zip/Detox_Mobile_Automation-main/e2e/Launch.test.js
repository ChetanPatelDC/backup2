describe('Login', () => {
  beforeAll(async () => {
    await device.launchApp();
  });

  beforeEach(async () => {
    await device.reloadReactNative();
  });

  it('should have logo image', async () => {
    await expect(element(by.id('logo-image'))).toBeVisible();
    await expect(element(by.id('loading-indicator'))).toBeVisible();
  });

  it('should navigate to onboarding screen', async () => {
    await waitFor(element(by.text('Next'))).toBeVisible().withTimeout(5000);
    await element(by.text('Next')).tap();
    await waitFor(element(by.text('Next'))).toBeVisible().withTimeout(5000);
    await element(by.text('Next')).tap();
    await waitFor(element(by.text('Login'))).toBeVisible().withTimeout(5000);
    await element(by.text('Login')).tap();
    //await waitFor(element(by.text('Email'))).toBeVisible().withTimeout(5000);
    //const email = element(by.text('Email'));
    //const password = element(by.text('Password'));
    //email.typeText('avitkl@gmail.com');
    //password.typeText('Avitkl@gmail.com');
    await waitFor(element(by.id('Login'))).toBeVisible().withTimeout(5000);
    await element(by.id('Login')).tap();
  });
});
