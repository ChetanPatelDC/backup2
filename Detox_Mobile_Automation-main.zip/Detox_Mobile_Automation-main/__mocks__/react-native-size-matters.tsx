module.exports = {
    scale: jest.fn((size) => size),
    verticalScale: jest.fn((size) => size),
    moderateScale: jest.fn((size) => size),
}