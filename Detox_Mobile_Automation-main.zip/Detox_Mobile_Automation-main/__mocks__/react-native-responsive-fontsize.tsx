export const RFValue = jest.fn((value) => value)
export const RFPercentage = jest.fn((value) => value)